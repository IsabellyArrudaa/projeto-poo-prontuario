package gui;

import javax.swing.JDialog;

public class TelaAtualizarExame extends JDialog {

    private static final long serialVersionUID = 1L;
}
